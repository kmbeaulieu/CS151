user: 007415772 (Weinrich, Krystle)

NOTES
Problem 1: I did the first 2 problems completely. I have my test cases commented out in main with what I expect the answers to be. For the third problem, I started the initial condition part but never got to finish the code.

Problem 2: no comments

Problem 3:
Instrument has a blank constructor to show that in String/Woodwind you do not need Instrument's attributes to create a constructor  for String/Woodwind. I have a blank constructor in Woodwind but not String to show I understand the differences in requiring a superclasses attributes or not when creating a constructor.

I gave the clarinet an enumeration of its parts to show it can have it's own unique attributes (and possibly functions for each part later). 

I gave instrument the function tune to show all instruments have something in comment when tuning (checking the key) but also override the tuning function to do their own unique thing (like blowing in a Woodwind or plucking a string for a String).